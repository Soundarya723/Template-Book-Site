/*
SQLyog Ultimate v10.00 Beta1
MySQL - 5.5.5-10.4.24-MariaDB : Database - readreview
*********************************************************************
*/


/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`readreview` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `readreview`;

/*Table structure for table `newbook` */

DROP TABLE IF EXISTS `newbook`;

CREATE TABLE `newbook` (
  `BookId` int(11) NOT NULL AUTO_INCREMENT,
  `BookName` varchar(50) DEFAULT NULL,
  `AuthorName` varchar(50) DEFAULT NULL,
  `PublisherName` varchar(50) DEFAULT NULL,
  `PublishedYear` varchar(10) DEFAULT NULL,
  `Image` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`BookId`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

/*Data for the table `newbook` */

insert  into `newbook`(`BookId`,`BookName`,`AuthorName`,`PublisherName`,`PublishedYear`,`Image`) 
values (6,'C Language','Dennis','Subhash','2022','Pic6.jpg'),
(9,'Verity','Collen Hoover','Sapna book house ','2018','Verity.jpg'),
(8,'C++','Jbaurne','Subhash','2022','C++.jpg');

/*Table structure for table `newreview` */

DROP TABLE IF EXISTS `newreview`;

CREATE TABLE `newreview` (
  `ReviewId` int(11) NOT NULL AUTO_INCREMENT,
  `UserId` int(11) DEFAULT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `EmailId` varchar(50) DEFAULT NULL,
  `PhoneNumber` varchar(20) DEFAULT NULL,
  `BookId` int(11) DEFAULT NULL,
  `BookName` varchar(50) DEFAULT NULL,
  `AuthorName` varchar(50) DEFAULT NULL,
  `PublisherName` varchar(50) DEFAULT NULL,
  `PublishedYear` varchar(10) DEFAULT NULL,
  `Rating` varchar(10) DEFAULT NULL,
  `Comments` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`ReviewId`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

/*Data for the table `newreview` */

insert  into `newreview`(`ReviewId`,`UserId`,`FirstName`,`LastName`,`EmailId`,`PhoneNumber`,`BookId`,`BookName`,`AuthorName`,`PublisherName`,`PublishedYear`,`Rating`,`Comments`) 
values (1,1,'aaa','aaa','aa@gmail.com','9886239083',6,'C Language','Dennis','Subhash','2022','5',NULL),
(2,1,'aaa','aaa','aa@gmail.com','9886239083',6,'C Language','Dennis','Subhash','2022','4',NULL),
(3,1,'aaa','aaa','aa@gmail.com','9886239083',6,'C Language','Dennis','Subhash','2022','3',NULL),
(4,1,'aaa','aaa','aa@gmail.com','9886239083',6,'C Language','Dennis','Subhash','2022','5',NULL),
(5,1,'aaa','aaa','aa@gmail.com','9886239083',6,'C Language','Dennis','Subhash','2022','2',NULL),
(6,1,'aaa','aaa','aa@gmail.com','9886239083',6,'C Language','Dennis','Subhash','2022','1',NULL),
(7,1,'aaa','aaa','aa@gmail.com','9886239083',8,'C++','Jbaurne','Subhash','2022','5','aaa');

/*Table structure for table `newuser` */

DROP TABLE IF EXISTS `newuser`;

CREATE TABLE `newuser` (
  `UserId` int(11) NOT NULL AUTO_INCREMENT,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `UserName` varchar(50) DEFAULT NULL,
  `Password` varchar(50) DEFAULT NULL,
  `EmailId` varchar(50) DEFAULT NULL,
  `PhoneNumber` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`UserId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

/*Data for the table `newuser` */

insert  into `newuser`(`UserId`,`FirstName`,`LastName`,`UserName`,`Password`,`EmailId`,`PhoneNumber`) 
values (1,'harshitha','gr','12345','harshitha@gmail.com','9886239083'),
(2,'Soundarya','S','soundarya','1234','soundarya@gmail.com','9234633644');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
