import os
STATIC_URL = '/static/'